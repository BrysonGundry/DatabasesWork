import * as React from "react";
import { Admin, Resource, fetchUtils } from 'react-admin';
import { GradesList, GradesEdit, GradesCreate } from "./Grades";
import { StudentsEdit, StudentsList, StudentsCreate, StudentsShow } from "./Students";
import RestClient from "./RestClient";

const httpClient = (url, options = {}) => {
    options.user = {
        authenticated: true,
        token: 'Basic ' + btoa('teacher:testing')
    };
    return fetchUtils.fetchJson(url, options);
};

const dataProvider = RestClient('http://18.224.31.50/project5', httpClient);

const App = () => (
    <Admin dataProvider={dataProvider}>
        <Resource name="students" list={StudentsList} show={StudentsShow} edit={StudentsEdit} create={StudentsCreate} />
        <Resource name="grades" list={GradesList} edit={GradesEdit} create={GradesCreate} />
    </Admin>
);

export default App;

