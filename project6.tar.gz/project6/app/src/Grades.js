import * as React from "react";
import { List, Datagrid, TextField, NumberField, ReferenceField, Edit, SimpleForm, TextInput, NumberInput, Create} from 'react-admin';

export const GradesList = props => (
    <List {...props}>
        <Datagrid rowClick="edit">

            <TextField source="id" />

            <ReferenceField label="Student" source="student_id" reference="students">
                <TextField source="name" />
            </ReferenceField>

            <TextField source="type" />
            <NumberField source="grade" />
            <NumberField source="max" />
        </Datagrid>
    </List>
);

export const GradesEdit = props => (
    <Edit {...props}>
        <SimpleForm>
            <TextField source="id" />

            <ReferenceField label="Student" source="student_id" reference="students">
                <TextField source="name" />
            </ReferenceField>

            <TextInput source="type" />
            <NumberInput source="grade" />
            <NumberInput source="max" />
        </SimpleForm>
    </Edit>
);

export const GradesCreate = props => (
    <Create {...props}>
        <SimpleForm>
            <TextInput source="student_id" />
            <TextInput source="type" />
            <NumberInput source="grade" />
            <NumberInput source="max" />
        </SimpleForm>
    </Create>
);
